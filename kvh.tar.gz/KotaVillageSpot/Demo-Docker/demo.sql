INSERT INTO `auth` VALUES ('guest','8859fcba18be290d598679d7fc225a69c314b9e3871f4d10b',1);
INSERT INTO `settings` VALUES ('demosite','true');
