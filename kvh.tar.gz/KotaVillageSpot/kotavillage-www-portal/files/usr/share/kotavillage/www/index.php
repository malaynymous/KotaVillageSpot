<?php

header("Location: /kotavillage/uam/");

?>
