<?php
header("Content-Type: text/javascript; charset=utf-8");

require_once('includes/site.inc.php');

$jsfile = basename($_GET['js'], '.js');
$jsfilecontents = file_get_contents("js/$jsfile.js");

$search = array(
    "###SERVERIPADDRESS###",
    'Nama pengguna diperlukan',
    'Adakah anda pasti anda mahu putuskan sambungan sekarang?',
    'Ralat memuatkan borang login generik',
    'Popup dihalang. Klik pautan di bawah untuk terus ke laman web anda dan membuka tetingkap status',
    'Log masuk',
    'Klik untuk membuka tetingkap status dan terus ke laman web anda',
    );
$replace = array(
    $lanIP,
    T_('Nama pengguna diperlukan'),
    T_('Adakah anda pasti anda mahu putuskan sambungan sekarang?'),
    T_('Ralat memuatkan borang login generik'),
    T_('Popup dihalang. Klik pautan di bawah untuk terus ke laman web anda dan membuka tetingkap status'),
    T_('Log masuk'),
    T_('Klik untuk membuka tetingkap status dan terus ke laman web anda'),
    );
$jsfilecontents = str_replace($search, $replace, $jsfilecontents);

echo "$jsfilecontents";

?>
