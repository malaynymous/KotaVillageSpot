<?php

namespace KotaVillage;


class AnonAuth
{
    public function getUsername()
    {
        return "Anon";
    }
}
